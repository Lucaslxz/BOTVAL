import uuid
import qrcode
from io import BytesIO
import unicodedata
import re
import logging
import json
import os

logger = logging.getLogger(__name__)

def obter_config(chave, padrao=None):
    """Obtém configuração do arquivo config.json"""
    try:
        with open('config/config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # Para chaves aninhadas como "pix.chave"
        if '.' in chave:
            parts = chave.split('.')
            result = config
            for part in parts:
                if part in result:
                    result = result[part]
                else:
                    return padrao
            return result
        
        return config.get(chave, padrao)
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        return padrao

def limpar_texto(texto: str) -> str:
    """Remove acentos e espaços de um texto"""
    if not texto:
        return ""
    
    texto = texto.strip().replace(" ", "")
    texto = unicodedata.normalize("NFD", texto)
    return ''.join(c for c in texto if unicodedata.category(c) != "Mn")

def limpar_txid(txid: str) -> str:
    """Limpa um txid para se adequar ao formato Pix"""
    if not txid:
        return "txid"
    
    return re.sub(r"[^a-zA-Z0-9]", "", txid)[:25] or "txid"

def validar_chave_pix(chave):
    """Validação básica de chave PIX"""
    if not chave:
        return False
    
    # CPF/CNPJ (apenas números)
    if re.match(r'^\d{11,14}$', chave):
        return True
    
    # Email (verificação básica)
    if '@' in chave and '.' in chave:
        return True
    
    # Telefone (+5511999999999)
    if re.match(r'^\+\d{12,13}$', chave):
        return True
    
    # Chave aleatória (UUID)
    if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$', chave, re.I):
        return True
    
    return False

def gerar_payload_pix(valor: float, chave: str = None, txid: str = None) -> str:
    """Gera o payload para um Pix copia e cola"""
    # Verificar e obter a chave
    if not chave:
        chave = obter_config("pix.chave")

    if not chave or not validar_chave_pix(chave):
        erro_msg = "❌ Chave Pix ausente ou inválida."
        logger.error(erro_msg)
        raise ValueError(erro_msg)
    
    # Gerar txid se não fornecido
    if txid is None:
        txid = str(uuid.uuid4())[:25]
    
    txid = limpar_txid(txid)
    
    # Obter informações do recebedor
    nome = limpar_texto(obter_config("pix.nome_recebedor") or "Loja Valorant")[:25] or "Loja Valorant"
    cidade = limpar_texto(obter_config("pix.cidade_recebedor") or "SAO PAULO")[:15] or "SAO PAULO"
    
    # Garantir que valor seja um float
    try:
        valor = float(valor)
        if valor <= 0:
            raise ValueError("Valor deve ser maior que zero")
    except (TypeError, ValueError) as e:
        logger.error(f"Erro ao processar valor para PIX: {e}")
        valor = 0.01  # Valor mínimo em caso de erro
    
    # Funções auxiliares para formatação
    def format_field(id: str, value: str) -> str:
        return f"{id}{len(value):02d}{value}"
    
    def calcular_crc16(payload: str) -> str:
        polinomio = 0x1021
        resultado = 0xFFFF
        
        for byte in payload.encode("utf-8"):
            resultado ^= byte << 8
            for _ in range(8):
                if resultado & 0x8000:
                    resultado = (resultado << 1) ^ polinomio
                else:
                    resultado <<= 1
                resultado &= 0xFFFF
                
        return hex(resultado)[2:].zfill(4).upper()
    
    # Construção do payload
    try:
        gui = "BR.GOV.BCB.PIX"
        merchant_info = format_field("00", gui) + format_field("01", chave)
        
        campo26 = format_field("26", merchant_info)
        campo52 = "52040000"
        campo53 = "5303986"
        campo54 = format_field("54", f"{valor:.2f}")
        campo58 = "5802BR"
        campo59 = format_field("59", nome)
        campo60 = format_field("60", cidade)
        campo62 = format_field("62", format_field("05", txid))
        
        payload_sem_crc = "000201" + campo26 + campo52 + campo53 + campo54 + campo58 + campo59 + campo60 + campo62 + "6304"
        payload_final = payload_sem_crc + calcular_crc16(payload_sem_crc)
        
        logger.debug(f"Payload PIX gerado com sucesso para valor R$ {valor:.2f}")
        return payload_final.strip()
    
    except Exception as e:
        logger.exception(f"Erro ao gerar payload PIX: {e}")
        raise ValueError(f"Erro ao gerar Pix: {str(e)}")

def gerar_qr_code_pix(payload: str) -> BytesIO:
    """Gera uma imagem QR Code para um payload PIX"""
    try:
        # Limpar o payload
        payload = payload.strip().replace("\n", "").replace("\r", "")
        
        # Gerar QR code com configurações otimizadas
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
        )
        
        qr.add_data(payload)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Salvar para um buffer de memória
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        
        logger.debug("QR Code PIX gerado com sucesso")
        return buffer
        
    except Exception as e:
        logger.exception(f"Erro ao gerar QR code PIX: {e}")
        
        # Fallback para QR simples em caso de erro
        try:
            qr_simple = qrcode.make(payload)
            buffer = BytesIO()
            qr_simple.save(buffer, format="PNG")
            buffer.seek(0)
            return buffer
            
        except Exception as fallback_error:
            logger.exception(f"Erro no fallback QR code: {fallback_error}")
            raise ValueError(f"Impossível gerar QR code: {str(e)}")
