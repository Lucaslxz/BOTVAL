import sqlite3
import os
import asyncio
import logging
from datetime import datetime

DB_PATH = 'data/accounts.db'
logger = logging.getLogger(__name__)

def setup_database():
    """Configurar banco de dados SQLite"""
    # Garantir que o diretório existe
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Criar tabelas necessárias
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS accounts (
        id TEXT PRIMARY KEY,
        rank TEXT,
        region TEXT,
        price TEXT,
        inventory_value TEXT,
        vp TEXT,
        rp TEXT,
        email_verified INTEGER,
        phone_verified INTEGER,
        last_activity TEXT,
        kingdom_credits TEXT,
        total_skins INTEGER,
        knives INTEGER,
        agents TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        total_price REAL,
        status TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER,
        account_id TEXT,
        price TEXT,
        FOREIGN KEY (order_id) REFERENCES orders (id),
        FOREIGN KEY (account_id) REFERENCES accounts (id)
    )
    ''')
    
    conn.commit()
    conn.close()
    
    logger.info("Banco de dados configurado com sucesso")

def save_account(account_info):
    """Salvar informações da conta no banco de dados"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Verificar se a conta já existe
    cursor.execute('SELECT id FROM accounts WHERE id = ?', (account_info['id'],))
    exists = cursor.fetchone() is not None
    
    if exists:
        # Atualizar conta existente
        cursor.execute('''
        UPDATE accounts SET
            rank = ?,
            region = ?,
            price = ?,
            inventory_value = ?,
            vp = ?,
            rp = ?,
            email_verified = ?,
            phone_verified = ?,
            last_activity = ?,
            kingdom_credits = ?,
            total_skins = ?,
            knives = ?,
            agents = ?
        WHERE id = ?
        ''', (
            account_info['rank'],
            account_info['region'],
            account_info['price'],
            account_info['inventory_value'],
            account_info['vp'],
            account_info.get('rp', '0'),
            1 if account_info.get('email_verified', 'Verificado') == 'Verificado' else 0,
            1 if account_info.get('phone_verified', 'Não Verificado') == 'Verificado' else 0,
            account_info.get('last_activity', ''),
            account_info.get('kingdom_credits', '0'),
            account_info.get('total_skins', 0),
            account_info.get('knives', 0),
            account_info.get('agents', 'Todos Desbloqueados'),
            account_info['id']
        ))
    else:
        # Inserir nova conta
        cursor.execute('''
        INSERT INTO accounts (
            id, rank, region, price, inventory_value, vp, rp,
            email_verified, phone_verified, last_activity,
            kingdom_credits, total_skins, knives, agents
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            account_info['id'],
            account_info['rank'],
            account_info['region'],
            account_info['price'],
            account_info['inventory_value'],
            account_info['vp'],
            account_info.get('rp', '0'),
            1 if account_info.get('email_verified', 'Verificado') == 'Verificado' else 0,
            1 if account_info.get('phone_verified', 'Não Verificado') == 'Verificado' else 0,
            account_info.get('last_activity', ''),
            account_info.get('kingdom_credits', '0'),
            account_info.get('total_skins', 0),
            account_info.get('knives', 0),
            account_info.get('agents', 'Todos Desbloqueados')
        ))
    
    conn.commit()
    conn.close()
    logger.info(f"Conta {account_info['id']} salva no banco de dados")

def get_account_from_db(account_id):
    """Obter informações da conta do banco de dados"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Permite acessar colunas pelo nome
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM accounts WHERE id = ?', (account_id,))
    row = cursor.fetchone()
    
    conn.close()
    
    if row:
        # Converter row para dicionário
        account_info = dict(row)
        # Converter booleanos
        account_info['email_verified'] = "Verificado" if account_info['email_verified'] else "Não Verificado"
        account_info['phone_verified'] = "Verificado" if account_info['phone_verified'] else "Não Verificado"
        return account_info
    return None

async def save_order(user_id, items, total_price):
    """Salvar um pedido no banco de dados"""
    # Simular operação assíncrona (pode ser substituída por banco de dados assíncrono)
    await asyncio.sleep(0.1)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Inserir pedido
    cursor.execute('''
    INSERT INTO orders (user_id, total_price, status)
    VALUES (?, ?, ?)
    ''', (str(user_id), total_price, 'pending'))
    
    # Obter ID do pedido inserido
    order_id = cursor.lastrowid
    
    # Inserir itens do pedido
    for item in items:
        cursor.execute('''
        INSERT INTO order_items (order_id, account_id, price)
        VALUES (?, ?, ?)
        ''', (order_id, item['account_id'], item['price']))
    
    conn.commit()
    conn.close()
    
    logger.info(f"Pedido {order_id} salvo no banco de dados para o usuário {user_id}")
    return order_id

async def update_order_status(order_id, status):
    """Atualizar status de um pedido"""
    # Simular operação assíncrona
    await asyncio.sleep(0.1)
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
    UPDATE orders SET status = ? WHERE id = ?
    ''', (status, order_id))
    
    conn.commit()
    conn.close()
    
    logger.info(f"Status do pedido {order_id} atualizado para '{status}'")
    return True

async def get_user_orders(user_id):
    """Obter pedidos de um usuário"""
    # Simular operação assíncrona
    await asyncio.sleep(0.1)
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # Permite acessar colunas pelo nome
    cursor = conn.cursor()
    
    # Obter pedidos
    cursor.execute('''
    SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC
    ''', (str(user_id),))
    orders = [dict(row) for row in cursor.fetchall()]
    
    # Para cada pedido, obter os itens
    for order in orders:
        cursor.execute('''
        SELECT oi.*, a.rank, a.region FROM order_items oi
        LEFT JOIN accounts a ON oi.account_id = a.id
        WHERE oi.order_id = ?
        ''', (order['id'],))
        order['items'] = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    logger.info(f"Recuperados {len(orders)} pedidos para o usuário {user_id}")
    return orders

async def get_system_stats():
    """Obter estatísticas do sistema"""
    # Simular operação assíncrona
    await asyncio.sleep(0.1)
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    # Total de contas
    cursor.execute('SELECT COUNT(*) as count FROM accounts')
    total_accounts = cursor.fetchone()['count']
    
    # Compras concluídas
    cursor.execute("SELECT COUNT(*) as count FROM orders WHERE status = 'aprovado'")
    completed_orders = cursor.fetchone()['count']
    
    # Valor total
    cursor.execute("SELECT SUM(total_price) as total FROM orders WHERE status = 'aprovado'")
    result = cursor.fetchone()
    total_value = result['total'] if result and result['total'] else 0
    
    # Compras recentes
    cursor.execute('''
    SELECT id, user_id, total_price, created_at 
    FROM orders 
    WHERE status = 'aprovado' 
    ORDER BY created_at DESC 
    LIMIT 5
    ''')
    recent_orders = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    return {
        "total_accounts": total_accounts,
        "completed_orders": completed_orders,
        "total_value": total_value,
        "recent_orders": recent_orders
    }
