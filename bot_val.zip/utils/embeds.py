import discord
import datetime

def embed_erro(mensagem: str, titulo: str = "Erro") -> discord.Embed:
    """Cria uma embed de erro padronizada"""
    embed = discord.Embed(
        title=titulo,
        description=mensagem,
        color=discord.Color.red(),
        timestamp=datetime.datetime.utcnow()
    )
    embed.set_footer(text="Valorant Store")
    return embed

def embed_sucesso(mensagem: str, titulo: str = "Sucesso") -> discord.Embed:
    """Cria uma embed de sucesso padronizada"""
    embed = discord.Embed(
        title=titulo,
        description=mensagem,
        color=0x00FF00,  # Verde
        timestamp=datetime.datetime.utcnow()
    )
    embed.set_footer(text="Valorant Store")
    return embed

def embed_info(mensagem: str, titulo: str = "Informação") -> discord.Embed:
    """Cria uma embed de informação padronizada"""
    embed = discord.Embed(
        title=titulo,
        description=mensagem,
        color=0xFD4556,  # Vermelho Valorant
        timestamp=datetime.datetime.utcnow()
    )
    embed.set_footer(text="Valorant Store")
    return embed

def embed_conta(account_info: dict) -> discord.Embed:
    """Cria uma embed para visualização de uma conta"""
    embed = discord.Embed(
        title=f"Conta Valorant #{account_info['id']}",
        color=0xFD4556,  # Vermelho Valorant
        timestamp=datetime.datetime.utcnow()
    )
    
    # Adicionar preço em destaque no título
    embed.description = f"**Preço: {account_info['price']}**"
    
    # Adicionar campos básicos
    embed.add_field(name="🏆 Rank", value=account_info['rank'], inline=True)
    embed.add_field(name="🌎 Região", value=account_info['region'], inline=True)
    
    # Adicionar informações adicionais
    embed.add_field(name="📊 Valor do Inventário", value=account_info['inventory_value'], inline=True)
    embed.add_field(name="💎 VP", value=account_info['vp'], inline=True)
    embed.add_field(name="🛒 Total de Skins", value=account_info.get('total_skins', 'N/A'), inline=True)
    
    # Adicionar verificações
    verificacoes = []
    if account_info.get('email_verified') == 'Verificado':
        verificacoes.append("✅ Email Verificado")
    else:
        verificacoes.append("❌ Email Não Verificado")
        
    if account_info.get('phone_verified') == 'Verificado':
        verificacoes.append("✅ Telefone Verificado")
    else:
        verificacoes.append("❌ Telefone Não Verificado")
    
    embed.add_field(name="🔐 Verificações", value="\n".join(verificacoes), inline=False)
    
    # Última atividade
    if "last_activity" in account_info and account_info["last_activity"]:
        embed.add_field(name="⏱️ Última Atividade", value=account_info["last_activity"], inline=False)
    
    embed.set_footer(text="Clique em 'Adicionar ao Carrinho' para comprar")
    
    return embed

def embed_conta_botoes(account_info: dict) -> tuple:
    """Cria uma embed para visualização de uma conta com botões"""
    embed = embed_conta(account_info)
    
    # Criar view com botão de adicionar ao carrinho
    from modules.cart_view import AdicionarCarrinhoView
    view = AdicionarCarrinhoView(account_info)
    
    return embed, view

def embed_carrinho(cart_data: dict) -> discord.Embed:
    """Cria uma embed para visualização do carrinho"""
    embed = discord.Embed(
        title="🛒 Seu Carrinho de Compras",
        description=f"Total de itens: {len(cart_data['items'])}",
        color=0xFD4556,  # Vermelho Valorant
        timestamp=datetime.datetime.utcnow()
    )
    
    total_price = 0
    
    # Adicionar cada item ao embed
    for i, item in enumerate(cart_data["items"], 1):
        try:
            # Extrair valor numérico do preço em reais
            price_str = item["price"].replace("R$", "").strip()
            price = float(price_str)
        except (ValueError, AttributeError):
            price = 0
            
        embed.add_field(
            name=f"#{i} - Conta {item['account_id']}",
            value=f"Rank: {item['rank']}\nRegião: {item['region']}\nPreço: {item['price']}",
            inline=(i % 2 != 0)  # Alternar entre inline e não-inline
        )
        
        total_price += price
    
    embed.add_field(
        name="💰 Total",
        value=f"R$ {total_price:.2f}",
        inline=False
    )
    
    embed.set_footer(text="Use os botões abaixo para gerenciar seu carrinho")
    
    return embed
