import discord
from discord.ext import commands
import json
import os
import logging
import datetime
from modules.discord_bot import setup_bot
from modules.scraper import setup_scraper
from utils.database import setup_database

# Configurar logging
def setup_logging():
    log_dir = 'logs'
    os.makedirs(log_dir, exist_ok=True)
    
    # Formato de data para o arquivo de log
    data_atual = datetime.datetime.now().strftime('%Y-%m-%d')
    log_file = os.path.join(log_dir, f'bot_{data_atual}.log')
    
    # Configurar logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    # Reduzir verbosidade de logs de outras bibliotecas
    logging.getLogger('discord').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('selenium').setLevel(logging.WARNING)
    
    return logging.getLogger('valorant_bot')

# Inicializar logger
logger = setup_logging()

# Carregar configurações
try:
    with open('config/config.json', 'r', encoding='utf-8') as f:
        config = json.load(f)
    logger.info("Configurações carregadas com sucesso.")
except Exception as e:
    logger.error(f"Erro ao carregar configurações: {e}")
    config = {
        "token": os.environ.get("DISCORD_TOKEN", ""),
        "prefix": "/"
    }

# Verificar token
if not config.get("token"):
    logger.critical("Token do Discord não encontrado. Defina em config.json ou variável de ambiente DISCORD_TOKEN.")
    exit(1)

# Inicializar o bot
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.reactions = True

# Criar o bot, usando uma classe que suporta comandos slash
bot = discord.Bot(intents=intents)

# Configurar banco de dados
try:
    setup_database()
    logger.info("Banco de dados configurado com sucesso.")
except Exception as e:
    logger.error(f"Erro ao configurar banco de dados: {e}")

# Configurar scraper
try:
    browser = setup_scraper(config.get('scraper', {}))
    logger.info("Scraper configurado com sucesso.")
except Exception as e:
    logger.error(f"Erro ao configurar scraper: {e}")
    browser = None

# Configurar bot Discord
try:
    setup_bot(bot, browser, config)
    logger.info("Bot Discord configurado com sucesso.")
except Exception as e:
    logger.error(f"Erro ao configurar bot Discord: {e}")

# Evento de inicialização
@bot.event
async def on_ready():
    logger.info(f"Bot conectado como {bot.user.name} (ID: {bot.user.id})")
    logger.info(f"Presente em {len(bot.guilds)} servidores")
    
    # Definir presença
    activity = discord.Activity(
        type=discord.ActivityType.playing,
        name=f"Valorant | /setar /config_valorant"
    )
    await bot.change_presence(activity=activity)

# Executar o bot
try:
    logger.info("Iniciando bot...")
    bot.run(config["token"])
except Exception as e:
    logger.critical(f"Erro fatal ao iniciar o bot: {e}")

# Limpeza ao encerrar
if browser:
    browser.quit()
    logger.info("Navegador encerrado e recursos liberados.")
