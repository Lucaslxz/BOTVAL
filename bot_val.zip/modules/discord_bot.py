import discord
import asyncio
import os
import datetime
import json
import logging
from modules.scraper import get_account_info
from utils.embeds import embed_erro, embed_sucesso, embed_info, embed_conta_botoes
from modules.cart_view import CompraView, AdicionarCarrinhoView, ConfigView

logger = logging.getLogger(__name__)

# Verificar se usuário é administrador
def is_admin(user):
    """Verifica se um usuário é administrador"""
    # Verificar se é admin do servidor
    if hasattr(user, 'guild_permissions') and user.guild_permissions.administrator:
        return True
        
    # Carregar configurações
    try:
        with open('config/config.json', 'r') as f:
            config = json.load(f)
            admin_ids = config.get('admin_ids', [])
            return user.id in admin_ids
    except:
        pass
    return False

def setup_bot(bot, browser, config):
    """Configurar comandos e eventos do bot"""
    
    # Comando slash para setar e postar contas em um único passo
    @bot.slash_command(name="setar", description="Configura e posta uma conta Valorant pelo ID e valor")
    async def setar_slash(
        ctx, 
        account_id: discord.Option(str, "ID da conta no shop.lppanel.com", required=True),
        valor: discord.Option(float, "Valor da conta em reais", required=True),
        channel: discord.Option(discord.TextChannel, "Canal onde a conta será postada (opcional)", required=False)
    ):
        # Verificar permissões
        if not ctx.author.guild_permissions.administrator and not is_admin(ctx.author):
            return await ctx.respond("❌ Você não tem permissão para usar este comando.", ephemeral=True)
            
        # Verificar formato do ID
        if not account_id.isdigit():
            return await ctx.respond("❌ ID da conta inválido! Use apenas números.", ephemeral=True)
        
        # Responder imediatamente para evitar timeout
        await ctx.respond(f"⏳ Processando conta #{account_id}...", ephemeral=True)
        
        # Extrair informações da conta
        account_info = get_account_info(browser, account_id)
        
        if not account_info:
            return await ctx.followup.send(f"❌ Não foi possível encontrar a conta #{account_id}.", ephemeral=True)
        
        # Atualizar o preço da conta (em reais)
        preco_formatado = f"R$ {valor:.2f}"
        account_info["price"] = preco_formatado
        
        # Salvar a conta no banco de dados
        from utils.database import save_account
        save_account(account_info)
        
        # Determinar o canal para postar
        target_channel = channel or ctx.channel
        
        # Criar embed com botões
        embed, view = embed_conta_botoes(account_info)
        
        # Postar no canal alvo
        await target_channel.send(embed=embed, view=view)
        
        # Confirmar salvamento e postagem
        if target_channel.id != ctx.channel.id:
            await ctx.followup.send(f"✅ Conta #{account_id} configurada a {preco_formatado} e postada com sucesso no canal {target_channel.mention}.", ephemeral=True)
        else:
            await ctx.followup.send(f"✅ Conta #{account_id} configurada a {preco_formatado} e postada com sucesso.", ephemeral=True)
    
    # Comando slash para configuração do sistema
    @bot.slash_command(name="config_valorant", description="Configura o sistema de vendas de contas Valorant")
    async def config_valorant_slash(ctx):
        # Verificar permissões
        if not ctx.author.guild_permissions.administrator and not is_admin(ctx.author):
            return await ctx.respond("❌ Você não tem permissão para usar este comando.", ephemeral=True)
        
        # Carregar configurações atuais
        try:
            with open('config/config.json', 'r', encoding='utf-8') as f:
                current_config = json.load(f)
        except Exception as e:
            current_config = {}
            await ctx.respond(f"⚠️ Aviso: Não foi possível carregar a configuração existente: {e}", ephemeral=True)
        
        # Criar embed de configuração
        embed = discord.Embed(
            title="⚙️ Configuração do Sistema de Contas Valorant",
            description="Use os botões abaixo para configurar diferentes aspectos do sistema de vendas.",
            color=0xFD4556
        )
        
        # Mostrar algumas configurações atuais
        config_status = []
        
        # Verificar canais
        admin_channel = current_config.get("admin_channel")
        if admin_channel:
            config_status.append(f"📢 Canal Admin: <#{admin_channel}>")
        else:
            config_status.append("📢 Canal Admin: ❌ Não configurado")
            
        category_id = current_config.get("category_id")
        if category_id:
            config_status.append(f"📁 Categoria: <#{category_id}>")
        else:
            config_status.append("📁 Categoria: ❌ Não configurada")
            
        # Verificar PIX
        pix_config = current_config.get("pix", {})
        pix_key = pix_config.get("chave")
        if pix_key:
            # Mascarar a chave para segurança
            masked_key = pix_key[:4] + "***" + pix_key[-4:] if len(pix_key) > 8 else "***"
            config_status.append(f"💰 Chave PIX: {masked_key}")
        else:
            config_status.append("💰 Chave PIX: ❌ Não configurada")
            
        # Adicionar status à embed
        if config_status:
            embed.add_field(
                name="📌 Status Atual",
                value="\n".join(config_status),
                inline=False
            )
        
        # Criar view com botões de configuração
        view = ConfigView(ctx, current_config)
        
        await ctx.respond(embed=embed, view=view, ephemeral=True)
    
    # Eventos para processar reações (fallback para botões)
    @bot.event
    async def on_reaction_add(reaction, user):
        # Ignorar reações do próprio bot
        if user.bot:
            return
        
        # Verificar se é a reação de carrinho
        if reaction.emoji == "🛒":
            message = reaction.message
            
            # Verificar se é uma mensagem de conta
            if message.embeds and message.embeds[0].title.startswith("Conta Valorant #"):
                account_id = message.embeds[0].title.split("#")[1].split()[0]
                
                # Buscar informações da conta
                from utils.database import get_account_from_db
                account_info = get_account_from_db(account_id)
                if not account_info:
                    # Se não encontrar no DB, buscar online
                    account_info = get_account_info(browser, account_id)
                
                if not account_info:
                    try:
                        await user.send(f"❌ Erro ao adicionar conta #{account_id} ao carrinho.")
                    except discord.Forbidden:
                        pass
                    return
                
                # Criar carrinho para o usuário
                from modules.cart import create_user_cart, add_to_cart
                cart = await create_user_cart(user.id)
                
                # Adicionar ao carrinho
                success, cart_updated = await add_to_cart(user.id, account_id, account_info)
                
                # Enviar DM com o carrinho
                try:
                    if success:
                        await user.send(f"✅ Conta #{account_id} adicionada ao carrinho!")
                        
                        # Criar view do carrinho para o usuário
                        from modules.cart_view import CarrinhoView
                        embed, view = CarrinhoView.create_cart_embed(cart_updated)
                        
                        await user.send(embed=embed, view=view)
                    else:
                        await user.send(f"❌ Esta conta já está no seu carrinho!")
                except discord.Forbidden:
                    # Não consegue enviar DM, ignorar silenciosamente
                    pass
    
    @bot.event
    async def on_application_command_error(ctx, error):
        """Manipulador global de erros para comandos slash"""
        if isinstance(error, discord.ApplicationCommandError):
            await ctx.respond(f"❌ Erro ao executar o comando: {str(error)}", ephemeral=True)
        else:
            # Erro genérico
            logger.error(f"Erro não tratado em comando slash: {error}")
            await ctx.respond("❌ Ocorreu um erro ao processar o comando.", ephemeral=True)

    return bot
