import json
import os
import datetime
import logging
from utils.database import save_order, get_user_orders
from utils.pix import gerar_payload_pix

logger = logging.getLogger(__name__)
CART_FILE = 'data/carts.json'

def load_carts():
    """Carregar dados de carrinhos existentes"""
    if os.path.exists(CART_FILE):
        with open(CART_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_carts(carts):
    """Salvar dados de carrinhos"""
    # Garantir que o diretório existe
    os.makedirs(os.path.dirname(CART_FILE), exist_ok=True)
    
    with open(CART_FILE, 'w') as f:
        json.dump(carts, f, indent=4)

async def create_user_cart(user_id):
    """Criar carrinho para um usuário se não existir"""
    carts = load_carts()
    
    if str(user_id) not in carts:
        carts[str(user_id)] = {
            "user_id": user_id,
            "items": [],
            "created_at": datetime.datetime.now().isoformat(),
            "updated_at": datetime.datetime.now().isoformat()
        }
        save_carts(carts)
    
    return carts[str(user_id)]

async def add_to_cart(user_id, account_id, account_info):
    """Adicionar uma conta ao carrinho de um usuário"""
    carts = load_carts()
    
    # Criar carrinho para o usuário se não existir
    if str(user_id) not in carts:
        carts[str(user_id)] = {
            "user_id": user_id,
            "items": [],
            "created_at": datetime.datetime.now().isoformat(),
            "updated_at": datetime.datetime.now().isoformat()
        }
    
    # Verificar se a conta já está no carrinho
    for item in carts[str(user_id)]["items"]:
        if item["account_id"] == account_id:
            return False, carts[str(user_id)]
    
    # Adicionar item ao carrinho
    cart_item = {
        "account_id": account_id,
        "price": account_info["price"],
        "rank": account_info["rank"],
        "region": account_info["region"],
        "added_at": datetime.datetime.now().isoformat()
    }
    
    carts[str(user_id)]["items"].append(cart_item)
    carts[str(user_id)]["updated_at"] = datetime.datetime.now().isoformat()
    
    save_carts(carts)
    return True, carts[str(user_id)]

async def remove_from_cart(user_id, account_id):
    """Remover uma conta do carrinho de um usuário"""
    carts = load_carts()
    
    if str(user_id) not in carts:
        return False, None
    
    initial_count = len(carts[str(user_id)]["items"])
    carts[str(user_id)]["items"] = [
        item for item in carts[str(user_id)]["items"] 
        if item["account_id"] != account_id
    ]
    
    if len(carts[str(user_id)]["items"]) == initial_count:
        return False, carts[str(user_id)]
    
    carts[str(user_id)]["updated_at"] = datetime.datetime.now().isoformat()
    save_carts(carts)
    return True, carts[str(user_id)]

async def get_cart(user_id):
    """Obter o carrinho de um usuário"""
    carts = load_carts()
    
    if str(user_id) not in carts or not carts[str(user_id)]["items"]:
        return None, "Seu carrinho está vazio!"
    
    return carts[str(user_id)], "Carrinho encontrado!"

async def clear_cart(user_id):
    """Limpar o carrinho de um usuário"""
    carts = load_carts()
    
    if str(user_id) not in carts:
        return False, None
    
    carts[str(user_id)]["items"] = []
    carts[str(user_id)]["updated_at"] = datetime.datetime.now().isoformat()
    
    save_carts(carts)
    return True, carts[str(user_id)]

async def process_checkout(user_id, cart_items):
    """Processar o checkout do carrinho"""
    try:
        # Calcular valor total da compra (usando valores em reais)
        total_price = 0
        for item in cart_items:
            try:
                # Extrair valor numérico do preço em reais
                price_str = item["price"].replace("R$", "").strip()
                price = float(price_str)
                total_price += price
            except (ValueError, AttributeError, IndexError):
                logger.warning(f"Erro ao processar preço: {item.get('price', 'N/A')}")
        
        # Registrar compra no banco de dados
        order_id = await save_order(user_id, cart_items, total_price)
        
        # Gerar payload PIX para pagamento
        try:
            payload = gerar_payload_pix(total_price)
        except Exception as e:
            logger.error(f"Erro ao gerar PIX: {e}")
            payload = None
        
        # Retornar dados para criação do canal de pagamento
        return {
            "order_id": order_id,
            "total_price": total_price,
            "pix_payload": payload,
            "items": cart_items,
            "status": "pending",
            "created_at": datetime.datetime.now().isoformat()
        }
    
    except Exception as e:
        logger.exception(f"Erro ao processar checkout: {e}")
        return None
