from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import io
from PIL import Image
import logging

logger = logging.getLogger(__name__)

def setup_scraper(config):
    """Configurar o navegador Selenium para scraping"""
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--window-size=1920,5000")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--no-sandbox")
    
    if config.get("user_agent"):
        options.add_argument(f"user-agent={config.get('user_agent')}")
    
    browser = webdriver.Chrome(options=options)
    return browser

def get_account_info(browser, account_id):
    """Extrair informações detalhadas de uma conta"""
    url = f"https://shop.lppanel.com/{account_id}"
    
    try:
        browser.get(url)
        
        # Aguardar carregamento da página
        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.TAG_NAME, "body"))
        )
        time.sleep(3)  # Tempo adicional para garantir carregamento completo
        
        # Verificar se a página carregou corretamente
        if "404" in browser.title or "Error" in browser.title:
            logger.warning(f"Página da conta {account_id} não encontrada")
            return None
        
        # Extrair informações básicas
        account_info = {}
        account_info["id"] = account_id
        
        try:
            # Preço - padronizado como "R$ 0.00" (será substituído pelo valor definido pelo admin)
            price_element = browser.find_element(By.CSS_SELECTOR, "div.price")
            account_info["price"] = "R$ 0.00" # Valor padrão, será definido pelo admin
        except:
            account_info["price"] = "R$ 0.00"
            
        try:
            # Rank
            rank_element = browser.find_element(By.CSS_SELECTOR, "div.rank")
            account_info["rank"] = rank_element.text.strip() if rank_element else "UNRANKED"
        except:
            account_info["rank"] = "UNRANKED"
            
        try:
            # Região
            region_element = browser.find_element(By.CSS_SELECTOR, "div.region")
            account_info["region"] = region_element.text.strip() if region_element else "N/A"
        except:
            account_info["region"] = "N/A"
            
        try:
            # Inventário
            inventory_element = browser.find_element(By.CSS_SELECTOR, "div.inventory-value")
            account_info["inventory_value"] = inventory_element.text.strip() if inventory_element else "0"
        except:
            account_info["inventory_value"] = "0"
            
        try:
            # VP
            vp_element = browser.find_element(By.CSS_SELECTOR, "div.vp-balance")
            account_info["vp"] = vp_element.text.strip() if vp_element else "0"
        except:
            account_info["vp"] = "0"
            
        try:
            # Email Verificado
            email_element = browser.find_element(By.CSS_SELECTOR, "div.email-verified")
            account_info["email_verified"] = "Verificado" if email_element and "verified" in email_element.get_attribute("class").lower() else "Não Verificado"
        except:
            account_info["email_verified"] = "Não Verificado"
        
        try:
            # Telefone Verificado
            phone_element = browser.find_element(By.CSS_SELECTOR, "div.phone-verified")
            account_info["phone_verified"] = "Verificado" if phone_element and "verified" in phone_element.get_attribute("class").lower() else "Não Verificado"
        except:
            account_info["phone_verified"] = "Não Verificado"
        
        # Contar skins e facas
        try:
            skin_elements = browser.find_elements(By.CSS_SELECTOR, "div.skin-item")
            account_info["total_skins"] = len(skin_elements)
        except:
            account_info["total_skins"] = 0
            
        try:
            knife_elements = browser.find_elements(By.CSS_SELECTOR, "div.knife-item")
            account_info["knives"] = len(knife_elements)
        except:
            account_info["knives"] = 0
        
        # Tentar encontrar o container de skins
        try:
            skins_container = browser.find_element(By.CSS_SELECTOR, "div.skins-container, div#skins")
            
            # Rolar para ver todas as skins
            browser.execute_script("arguments[0].scrollIntoView();", skins_container)
            
            # Rolar dentro do container para garantir que todas as skins sejam carregadas
            for _ in range(5):  # Rolar algumas vezes
                browser.execute_script("arguments[0].scrollBy(0, 500);", skins_container)
                time.sleep(0.5)
            
            # Capturar screenshot da área de skins
            skins_screenshot = skins_container.screenshot_as_png
            account_info["skins_image"] = Image.open(io.BytesIO(skins_screenshot))
            
        except Exception as e:
            # Se não conseguir encontrar o container específico, tente capturar a página inteira
            logger.warning(f"Não foi possível capturar o container de skins: {e}")
            try:
                # Capturar screenshot da página inteira para backup
                full_screenshot = browser.get_screenshot_as_png()
                account_info["full_image"] = Image.open(io.BytesIO(full_screenshot))
            except:
                pass
        
        logger.info(f"Informações da conta {account_id} extraídas com sucesso")
        return account_info
    
    except Exception as e:
        logger.error(f"Erro ao extrair informações da conta {account_id}: {e}")
        return None
