import discord
from discord.ui import View, Button
import asyncio
import datetime
import random
import string
import traceback
import logging
from io import BytesIO
from utils.database import update_order_status
from utils.pix import gerar_qr_code_pix
import json
import os

logger = logging.getLogger(__name__)

def gerar_id_curto(tamanho=8):
    """Gera um ID curto alfanumérico"""
    caracteres = string.ascii_uppercase + string.digits
    return ''.join(random.choice(caracteres) for _ in range(tamanho))

def obter_config(chave, padrao=None):
    """Função temporária para obter configurações"""
    try:
        with open('config/config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # Para chaves aninhadas como "pix.chave"
        if '.' in chave:
            parts = chave.split('.')
            result = config
            for part in parts:
                if part in result:
                    result = result[part]
                else:
                    return padrao
            return result
            
        return config.get(chave, padrao)
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        return padrao

class AdicionarCarrinhoView(discord.ui.View):
    def __init__(self, account_info):
        super().__init__(timeout=None)
        self.account_info = account_info
        
        # Adicionar botão de preço não clicável 
        price_button = discord.ui.Button(
            style=discord.ButtonStyle.secondary,
            label=f"💰 {account_info['price']}",
            disabled=True,
            custom_id="price_display"
        )
        self.add_item(price_button)
    
    @discord.ui.button(label="🛒 Adicionar ao Carrinho", style=discord.ButtonStyle.success, custom_id="adicionar_carrinho")
    async def adicionar_carrinho(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Verificar se o usuário já tem um carrinho
        from modules.cart import create_user_cart, add_to_cart
        
        user_id = interaction.user.id
        
        # Criar carrinho se não existir
        cart = await create_user_cart(user_id)
        
        # Adicionar ao carrinho
        success, cart_updated = await add_to_cart(user_id, self.account_info["id"], self.account_info)
        
        if success:
            # Responder privadamente
            await interaction.response.send_message("✅ Conta adicionada ao carrinho!", ephemeral=True)
            
            # Enviar DM com o carrinho
            try:
                # Criar view do carrinho para o usuário
                embed, view = CarrinhoView.create_cart_embed(cart_updated)
                await interaction.user.send(embed=embed, view=view)
            except discord.Forbidden:
                # Não tem permissão para DM, avisar no canal
                await interaction.followup.send("❌ Não consegui enviar o carrinho por DM. Verifique suas configurações de privacidade.", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Esta conta já está no seu carrinho!", ephemeral=True)

class CarrinhoView(discord.ui.View):
    def __init__(self, user_id, cart_data):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.cart_data = cart_data
    
    @staticmethod
    def create_cart_embed(cart_data):
        """Criar embed do carrinho com botões"""
        from utils.embeds import embed_carrinho
        embed = embed_carrinho(cart_data)
        view = CarrinhoView(cart_data["user_id"], cart_data)
        return embed, view
    
    @discord.ui.button(label="💰 Finalizar Compra", style=discord.ButtonStyle.success, custom_id="finalizar")
    async def finalizar_compra(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.cart_data["items"]:
            return await interaction.response.send_message("❌ Seu carrinho está vazio!", ephemeral=True)
        
        # Processar checkout
        from modules.cart import process_checkout
        checkout_data = await process_checkout(self.user_id, self.cart_data["items"])
        
        if not checkout_data:
            return await interaction.response.send_message("❌ Erro ao processar a compra. Tente novamente.", ephemeral=True)
        
        # Criar canal de pagamento
        try:
            # Obter guild (do canal atual ou primeiro servidor disponível)
            guild = interaction.guild
            if not guild:
                # Se a interação aconteceu em DM, procurar em servidores comuns
                guilds = [g for g in interaction.client.guilds if g.get_member(self.user_id)]
                if not guilds:
                    return await interaction.response.send_message("❌ Não consigo criar um canal para pagamento. Entre em contato com o suporte.", ephemeral=True)
                guild = guilds[0]
            
            # Buscar usuário no servidor
            member = guild.get_member(self.user_id)
            if not member:
                try:
                    member = await guild.fetch_member(self.user_id)
                except:
                    return await interaction.response.send_message("❌ Não consigo encontrar você no servidor. Entre em contato com o suporte.", ephemeral=True)
            
            # Obter categoria para o canal
            import json
            try:
                with open('config/config.json', 'r') as f:
                    config = json.load(f)
                category_id = config.get("category_id")
            except:
                category_id = None
            
            category = None
            if category_id:
                category = guild.get_channel(int(category_id))
            
            # Nome do canal
            channel_name = f"compra-{member.name.lower()[:10]}-{datetime.datetime.now().strftime('%d%m%y')}"
            
            # Permissões
            overwrites = {
                guild.default_role: discord.PermissionOverwrite(read_messages=False),
                member: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
            }
            
            # Adicionar admins
            try:
                admin_ids = config.get("admin_ids", [])
                for admin_id in admin_ids:
                    admin = guild.get_member(int(admin_id))
                    if admin:
                        overwrites[admin] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
            except:
                pass
            
            # Criar canal
            if category:
                channel = await category.create_text_channel(channel_name, overwrites=overwrites)
            else:
                channel = await guild.create_text_channel(channel_name, overwrites=overwrites)
            
            # Calcular valor total
            total_price = 0
            for item in self.cart_data["items"]:
                try:
                    # Extrair valor numérico do preço em reais
                    price_str = item["price"].replace("R$", "").strip()
                    price = float(price_str)
                    total_price += price
                except (ValueError, AttributeError):
                    logger.warning(f"Erro ao processar preço: {item.get('price', 'N/A')}")
            
            # Criar embed
            embed = discord.Embed(
                title="🛒 Finalização da Compra",
                description=f"Por favor, complete o pagamento para receber suas contas Valorant.",
                color=0xFD4556
            )
            
            embed.add_field(
                name="💰 Valor Total",
                value=f"R$ {total_price:.2f}",
                inline=False
            )
            
            # Listar contas
            accounts_text = ""
            for i, item in enumerate(self.cart_data["items"], 1):
                accounts_text += f"{i}. Conta #{item['account_id']} - {item['rank']} - {item['price']}\n"
            
            embed.add_field(
                name="🎮 Contas no Carrinho",
                value=accounts_text or "Nenhuma conta selecionada",
                inline=False
            )
            
            embed.add_field(
                name="⏳ Status",
                value="Aguardando pagamento",
                inline=False
            )
            
            embed.add_field(
                name="📋 Instruções",
                value="1. Clique no botão 'Pix Copia e Cola' ou 'QR Code'\n2. Realize o pagamento\n3. Aguarde a aprovação pela equipe",
                inline=False
            )
            
            embed.set_footer(text=f"ID da Compra: {checkout_data['order_id']} • {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}")
            
            # Criar view para pagamento com PIX
            from modules.cart_view import CompraView
            accounts_info = {}
            from utils.database import get_account_from_db
            for item in self.cart_data["items"]:
                account_info = get_account_from_db(item["account_id"])
                if account_info:
                    accounts_info[item["account_id"]] = account_info
            
            payment_view = CompraView(
                compra_id=checkout_data['order_id'],
                canal=channel,
                payload=checkout_data.get('pix_payload'),
                comprador_id=self.user_id,
                accounts_info=accounts_info
            )
            
            # Enviar para o canal
            await channel.send(f"{member.mention} sua compra foi iniciada!", embed=embed, view=payment_view)
            
            # Responder na DM
            await interaction.response.send_message(f"✅ Seu pedido foi iniciado! Por favor, acesse o canal {channel.mention} para finalizar o pagamento.", ephemeral=True)
            
            # Limpar carrinho
            from modules.cart import clear_cart
            await clear_cart(self.user_id)
            
            # Desabilitar botões
            for child in self.children:
                child.disabled = True
            
            await interaction.edit_original_response(view=self)
            
        except Exception as e:
            import traceback
            error_details = traceback.format_exc()
            logger.error(f"Erro ao criar canal de pagamento: {e}\n{error_details}")
            await interaction.response.send_message(f"❌ Erro ao criar canal de pagamento: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label="🗑️ Remover Item", style=discord.ButtonStyle.danger, custom_id="remover")
    async def remover_item(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.cart_data["items"]:
            return await interaction.response.send_message("❌ Seu carrinho já está vazio!", ephemeral=True)
        
        # Criar lista de opções para o usuário escolher qual item remover
        options = []
        for i, item in enumerate(self.cart_data["items"]):
            options.append(
                discord.SelectOption(
                    label=f"Conta #{item['account_id']} - {item['rank']}",
                    value=item['account_id'],
                    description=f"Preço: {item['price']}"
                )
            )
        
        # Criar select menu
        select = discord.ui.Select(
            placeholder="Selecione o item para remover",
            options=options,
            custom_id="remover_select"
        )
        
        # Função para quando um item for selecionado
        async def select_callback(interaction):
            # Remover item do carrinho
            from modules.cart import remove_from_cart
            account_id = select.values[0]
            success, cart_updated = await remove_from_cart(self.user_id, account_id)
            
            if success:
                # Obter carrinho atualizado
                from modules.cart import get_cart
                cart, _ = await get_cart(self.user_id)
                
                if cart and cart["items"]:
                    # Atualizar embed e view
                    embed, view = CarrinhoView.create_cart_embed(cart)
                    await interaction.response.edit_message(embed=embed, view=view)
                else:
                    # Carrinho vazio
                    empty_embed = discord.Embed(
                        title="🛒 Seu Carrinho de Compras",
                        description="Seu carrinho está vazio!",
                        color=0xFD4556
                    )
                    await interaction.response.edit_message(embed=empty_embed, view=None)
            else:
                await interaction.response.send_message("❌ Não foi possível remover o item do carrinho.", ephemeral=True)
        
        select.callback = select_callback
        
        # Criar view temporária apenas com o select
        temp_view = discord.ui.View()
        temp_view.add_item(select)
        
        await interaction.response.send_message("Selecione o item que deseja remover:", view=temp_view, ephemeral=True)
    
    @discord.ui.button(label="🧹 Limpar Carrinho", style=discord.ButtonStyle.secondary, custom_id="limpar")
    async def limpar_carrinho(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.cart_data["items"]:
            return await interaction.response.send_message("❌ Seu carrinho já está vazio!", ephemeral=True)
        
        # Confirmar antes de limpar
        confirm_view = discord.ui.View()
        confirm_view.add_item(discord.ui.Button(label="✅ Sim, limpar", style=discord.ButtonStyle.danger, custom_id="confirm_limpar"))
        confirm_view.add_item(discord.ui.Button(label="❌ Não, cancelar", style=discord.ButtonStyle.secondary, custom_id="cancel_limpar"))
        
        async def confirm_callback(interaction):
            # Limpar carrinho
            from modules.cart import clear_cart
            await clear_cart(self.user_id)
            
            # Atualizar mensagem
            empty_embed = discord.Embed(
                title="🛒 Seu Carrinho de Compras",
                description="Seu carrinho foi esvaziado!",
                color=0xFD4556
            )
            
            # Atualizar a mensagem original do carrinho
            await interaction.message.edit(embed=empty_embed, view=None)
            
            # Responder à confirmação
            await interaction.response.edit_message(content="✅ Seu carrinho foi esvaziado!", view=None)
        
        async def cancel_callback(interaction):
            await interaction.response.edit_message(content="❌ Operação cancelada.", view=None)
        
        # Adicionar callbacks aos botões
        confirm_view.children[0].callback = confirm_callback
        confirm_view.children[1].callback = cancel_callback
        
        await interaction.response.send_message("Tem certeza que deseja limpar o carrinho?", view=confirm_view, ephemeral=True)

class CompraView(View):
    def __init__(self, compra_id: int, canal, payload: str = None, comprador_id: int = None, accounts_info=None):
        super().__init__(timeout=None)
        self.compra_id = compra_id
        self.canal = canal
        self.payload = payload
        self.comprador_id = comprador_id
        self.accounts_info = accounts_info or {}
        self.processando = False  # Flag para evitar processamento duplicado
        
    async def enviar_log(self, guild, embed):
        """Envia log administrativo para o canal configurado"""
        try:
            canal_log_id = obter_config("admin_channel")
            if canal_log_id:
                canal_log = guild.get_channel(int(canal_log_id))
                if canal_log:
                    await canal_log.send(embed=embed)
                else:
                    logger.warning(f"Canal de log administrativo {canal_log_id} não encontrado")
        except Exception as e:
            logger.error(f"Erro ao enviar log administrativo: {e}")
        
    async def enviar_log_publico(self, interaction, dono, dados_compra):
        """Envia log público com uma embed estruturada"""
        canal_publico_id = obter_config("public_log_channel")
        if not canal_publico_id:
            logger.warning("Canal de log público não configurado")
            return
            
        canal_publico = interaction.guild.get_channel(int(canal_publico_id))
        if not canal_publico:
            logger.warning(f"Canal de log público {canal_publico_id} não encontrado")
            return
            
        try:
            # Criar uma embed estruturada para o log público
            embed = discord.Embed(color=0xFD4556)  # Cor Valorant
            
            # Adicionar imagem de perfil como thumbnail
            embed.set_author(name=f"{dono.name}", icon_url=dono.display_avatar.url)
            
            # Título da embed
            embed.title = "🎮 NOVA CONTA VALORANT ADQUIRIDA"
            
            # Campos da embed
            embed.add_field(name="📝 Conta", value=f"`#{dados_compra['account_id']}`", inline=True)
            embed.add_field(name="💰 Valor Pago", value=f"R$ {dados_compra['valor']:.2f}", inline=True)
            embed.add_field(name="🏆 Rank", value=f"{dados_compra.get('rank', 'Desconhecido')}", inline=True)
            
            # Adicionar timestamp
            embed.timestamp = discord.utils.utcnow()
            embed.set_footer(text=f"VALORANT STORE • {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}")
            
            # Criar botão de compra
            view = discord.ui.View(timeout=None)
            canal_link = dados_compra.get("canal_origem") or self.canal.id
            if canal_link:
                view.add_item(discord.ui.Button(
                    label="🛒 Ver Contas Disponíveis", 
                    url=f"https://discord.com/channels/{interaction.guild.id}/{canal_link}",
                    style=discord.ButtonStyle.link
                ))
                
            # Enviar a embed
            await canal_publico.send(embed=embed, view=view)
            logger.info(f"Log público enviado com sucesso para o canal {canal_publico_id}")
            
        except Exception as e:
            error_details = traceback.format_exc()
            logger.error(f"Erro ao enviar embed de log público: {e}\n{error_details}")
            
            # Tentar método alternativo em caso de erro
            try:
                # Mensagem simples como fallback
                mensagem = f"🎮 **NOVA CONTA ADQUIRIDA!** {dono.mention} comprou a conta `#{dados_compra['account_id']}` por R$ {dados_compra['valor']:.2f}"
                await canal_publico.send(mensagem)
            except Exception as fallback_error:
                logger.error(f"Falha ao enviar mensagem de fallback: {fallback_error}")
    
    @discord.ui.button(label="📎 Pix Copia e Cola", style=discord.ButtonStyle.success, custom_id="pix_copia")
    async def copia_pix(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.payload:
            payload = self.payload.strip().replace("\n", "").replace("\r", "")
            await interaction.response.send_message(f"🔗 Pix Copia e Cola:\n```{payload}```", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Payload Pix não carregada.", ephemeral=True)
    
    @discord.ui.button(label="🖼️ QR Code", style=discord.ButtonStyle.secondary, custom_id="pix_qr")
    async def qr_pix(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            if self.payload:
                buffer = gerar_qr_code_pix(self.payload)
                await interaction.response.send_message(
                    "🖼️ QR code gerado aqui:", 
                    file=discord.File(buffer, filename="pix_qr.png"),
                    ephemeral=True
                )
            else:
                await interaction.response.send_message("❌ Payload Pix não disponível para gerar QR.", ephemeral=True)
        except Exception as e:
            logger.error(f"Erro ao gerar QR code: {e}")
            await interaction.response.send_message(f"❌ Erro ao gerar QR: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label="✅ Aprovar compra", style=discord.ButtonStyle.success, custom_id="aprovar")
    async def aprovar_compra(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Verificar permissões administrativas
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message(
                "❌ Apenas administradores podem aprovar compras.",
                ephemeral=True
            )
        
        # Evitar processamento duplicado
        if self.processando:
            return await interaction.response.send_message("⏳ Esta compra já está sendo processada...", ephemeral=True)
            
        self.processando = True
        
        try:
            # Gerar ID simplificado para a aprovação
            id_simplificado = f"VAL{gerar_id_curto(6)}"
            
            # Buscar dados da compra para aprovação
            dados_compra = {
                "compra_id": self.compra_id,
                "account_id": ", ".join(self.accounts_info.keys()),
                "valor": sum(float(info.get("price", "R$ 0.00").replace("R$", "").strip()) for info in self.accounts_info.values()),
                "rank": ", ".join(info.get("rank", "Desconhecido") for info in self.accounts_info.values())
            }
            
            # Atualizar status da compra
            await update_order_status(self.compra_id, "aprovado")
            
            # Desabilitar todos os botões
            for item in self.children:
                item.disabled = True
                
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(f"✅ Compra aprovada! Enviando produto em **10 segundos...**\nID de Compra: `{id_simplificado}`")
            
            # Aguardar 10 segundos
            await asyncio.sleep(10)
            
            # Buscar usuário comprador
            try:
                dono = self.canal.guild.get_member(self.comprador_id)
                if dono is None:
                    dono = await self.canal.guild.fetch_member(self.comprador_id)
            except Exception as e:
                logger.exception(f"Erro ao buscar membro: {e}")
                try:
                    dono = await interaction.client.fetch_user(self.comprador_id)
                except Exception as user_error:
                    logger.error(f"Falha ao buscar usuário {self.comprador_id}: {user_error}")
                    await interaction.followup.send("❌ Não foi possível identificar o comprador com base no ID salvo.", ephemeral=True)
                    self.processando = False
                    return
            
            if not dono:
                await interaction.followup.send("❌ Não foi possível identificar o comprador com base no ID salvo.", ephemeral=True)
                self.processando = False
                return
                
            # Enviar mensagem de aprovação e credenciais ao comprador
            try:
                # Criar embed com as informações das contas
                embed_entrega = discord.Embed(
                    title="📦 Conta(s) Valorant Entregue(s)!",
                    description="Seus dados de acesso estão prontos para uso.",
                    color=0x00FF00  # Verde
                )
                
                # Adicionar informações de cada conta
                for account_id, info in self.accounts_info.items():
                    # Informações fictícias de login (substitua pelo sistema real)
                    login_info = f"Email: conta{account_id}@example.com\nSenha: senhasegura123"
                    
                    embed_entrega.add_field(
                        name=f"🎮 Conta #{account_id} - {info.get('rank', 'Desconhecido')}",
                        value=f"```{login_info}```",
                        inline=False
                    )
                
                embed_entrega.add_field(
                    name="🔑 Importante!",
                    value="⚠️ Recomendamos trocar a senha imediatamente após o primeiro acesso.",
                    inline=False
                )
                
                embed_entrega.add_field(
                    name="📋 ID da Compra",
                    value=f"`{id_simplificado}`",
                    inline=False
                )
                
                embed_entrega.set_footer(text=f"Valorant Store • {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}")
                
                await dono.send(embed=embed_entrega)
                logger.info(f"Credenciais enviadas com sucesso para {dono.name} (ID: {dono.id})")
                
            except Exception as e:
                logger.exception(f"Erro ao enviar credenciais ao comprador: {e}")
                await interaction.followup.send("⚠️ Não foi possível enviar credenciais ao comprador por DM, mas a compra foi aprovada.", ephemeral=True)
            
            # Log administrativo com ID simplificado
            embed_log = discord.Embed(title="✅ Compra Aprovada", color=discord.Color.green())
            embed_log.add_field(name="🆔 ID da Compra", value=id_simplificado, inline=True)
            embed_log.add_field(name="💰 Valor", value=f"R$ {dados_compra['valor']:.2f}", inline=True)
            embed_log.add_field(name="📦 Produto", value=f"`{dados_compra['account_id']}`", inline=True)
            embed_log.add_field(name="👤 Usuário", value=f"{dono.mention}", inline=False)
            embed_log.timestamp = discord.utils.utcnow()
            
            await self.enviar_log(interaction.guild, embed_log)
            
            # Log público sem ID da compra
            await self.enviar_log_publico(interaction, dono, dados_compra)
            
            # Deletar o canal com uma pausa
            await self.canal.send("✅ Compra aprovada com sucesso! Este canal será fechado em 10 segundos...")
            await asyncio.sleep(10)
            await self.canal.delete()
            
        except Exception as e:
            error_details = traceback.format_exc()
            logger.error(f"Erro durante a aprovação da compra: {e}\n{error_details}")
            await interaction.followup.send("❌ Ocorreu um erro durante o processamento da compra.", ephemeral=True)
            
        finally:
            self.processando = False
    
        @discord.ui.button(label="❌ Cancelar compra", style=discord.ButtonStyle.danger, custom_id="cancelar")
        async def cancelar_compra(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Evitar processamento duplicado
         if self.processando:
            return await interaction.response.send_message("⏳ Esta compra já está sendo processada...", ephemeral=True)
            
        self.processando = True
        
        try:
            # Atualizar status da compra
            await update_order_status(self.compra_id, "cancelado")
            
            # Desabilitar todos os botões
            for item in self.children:
                item.disabled = True
                
            await interaction.response.edit_message(view=self)
            
            # Usando ID simplificado para log de cancelamento também
            id_simplificado = f"VAL{gerar_id_curto(6)}"
            
            embed_cancelamento = discord.Embed(
                title="❌ Compra Cancelada",
                description="Este carrinho será removido em 10 segundos...",
                color=discord.Color.red()
            )
            
            await interaction.followup.send(embed=embed_cancelamento)
            
            # Log administrativo
            embed_log = discord.Embed(title="❌ Compra Cancelada", color=discord.Color.red())
            embed_log.add_field(name="🆔 ID da Compra", value=id_simplificado, inline=True)
            
            account_ids = ", ".join(self.accounts_info.keys())
            valor_total = sum(float(info.get("price", "R$ 0.00").replace("R$", "").strip()) for info in self.accounts_info.values())
            
            embed_log.add_field(name="💰 Valor", value=f"R$ {valor_total:.2f}", inline=True)
            embed_log.add_field(name="📦 Produto", value=f"`{account_ids}`", inline=True)
            embed_log.add_field(name="📌 Motivo", value="Cancelada pelo usuário.", inline=False)
            embed_log.add_field(name="👤 Usuário", value=f"{interaction.user.mention}", inline=False)
            embed_log.timestamp = discord.utils.utcnow()
            
            await self.enviar_log(interaction.guild, embed_log)
            
            # Enviar mensagem ao comprador
            if self.comprador_id:
                try:
                    dono = interaction.guild.get_member(self.comprador_id)
                    if dono:
                        mensagem_cancelamento = (
                            f"❌ Sua compra das contas Valorant (`{account_ids}`) foi cancelada.\n\n"
                            f"Se você acredita que isso foi um engano, entre em contato com o suporte."
                        )
                        try:
                            await dono.send(mensagem_cancelamento)
                        except:
                            logger.warning(f"Não foi possível enviar DM ao usuário {self.comprador_id}")
                except:
                    pass
            
            # Esperar e deletar canal
            await asyncio.sleep(10)
            await self.canal.delete()
            
        except Exception as e:
            error_details = traceback.format_exc()
            logger.error(f"Erro durante o cancelamento da compra: {e}\n{error_details}")
            await interaction.followup.send("❌ Ocorreu um erro durante o cancelamento da compra.", ephemeral=True)
            
        finally:
            self.processando = False

# Classes para configuração do sistema
class ConfigModal(discord.ui.Modal):
    def __init__(self, config_key, title, placeholder):
        super().__init__(title=title)
        self.config_key = config_key
        
        # Adicionar campo de texto
        self.valor = discord.ui.TextInput(
            label="Valor",
            placeholder=placeholder,
            required=True,
            style=discord.TextInputStyle.short
        )
        self.add_item(self.valor)
    
    async def on_submit(self, interaction: discord.Interaction):
        # Carregar configuração
        try:
            with open('config/config.json', 'r', encoding='utf-8') as f:
                config = json.load(f)
        except:
            config = {}
        
        # Verificar se é uma chave aninhada (ex: pix.chave)
        if '.' in self.config_key:
            parts = self.config_key.split('.')
            if len(parts) == 2:
                # Criar categoria se não existir
                if parts[0] not in config:
                    config[parts[0]] = {}
                
                # Definir valor
                config[parts[0]][parts[1]] = self.valor.value
        elif self.config_key == "add_admin":
            # Caso especial: adicionar admin
            try:
                admin_id = int(self.valor.value.strip())
                
                # Inicializar lista se não existir
                if "admin_ids" not in config:
                    config["admin_ids"] = []
                
                # Adicionar se não existir
                if admin_id not in config["admin_ids"]:
                    config["admin_ids"].append(admin_id)
                    
                    # Tentar obter informações do usuário
                    user = interaction.client.get_user(admin_id)
                    if user:
                        username = user.name
                    else:
                        username = f"ID: {admin_id}"
                else:
                    await interaction.response.send_message("⚠️ Este usuário já é um administrador.", ephemeral=True)
                    return
            except ValueError:
                await interaction.response.send_message("❌ ID de usuário inválido. Use apenas números.", ephemeral=True)
                return
        else:
            # Chave simples
            config[self.config_key] = self.valor.value
        
        # Salvar configuração
        with open('config/config.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4)
        
        # Confirmar salvamento
        await interaction.response.send_message(f"✅ Configuração '{self.config_key}' salva com sucesso!", ephemeral=True)

class ChannelSelectModal(discord.ui.Modal):
    def __init__(self, config_key, title):
        super().__init__(title=title)
        self.config_key = config_key
        
        # Adicionar campo de texto
        self.channel_id = discord.ui.TextInput(
            label="ID do Canal",
            placeholder="Digite o ID do canal (apenas números)",
            required=True,
            style=discord.TextInputStyle.short
        )
        self.add_item(self.channel_id)
    
    async def on_submit(self, interaction: discord.Interaction):
        # Validar ID do canal
        try:
            channel_id = int(self.channel_id.value.strip())
        except ValueError:
            await interaction.response.send_message("❌ ID de canal inválido. Use apenas números.", ephemeral=True)
            return
        
        # Verificar se o canal existe
        channel = interaction.client.get_channel(channel_id)
        if not channel:
            try:
                channel = await interaction.client.fetch_channel(channel_id)
            except:
                await interaction.response.send_message("❌ Canal não encontrado. Verifique o ID e tente novamente.", ephemeral=True)
                return
        
        # Carregar configuração
        try:
            with open('config/config.json', 'r', encoding='utf-8') as f:
                config = json.load(f)
        except:
            config = {}
        
        # Salvar ID do canal na configuração
        config[self.config_key] = channel_id
        
        # Salvar configuração
        with open('config/config.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4)
        
        # Confirmar salvamento
        await interaction.response.send_message(f"✅ Canal {channel.mention} configurado com sucesso para '{self.config_key}'!", ephemeral=True)

class MessageModal(discord.ui.Modal):
    def __init__(self, config_key, title):
        super().__init__(title=title)
        self.config_key = config_key
        
        # Carregar mensagem atual (se existir)
        try:
            with open('config/config.json', 'r', encoding='utf-8') as f:
                config = json.load(f)
                current_message = config.get(config_key, "")
        except:
            current_message = ""
        
        # Adicionar campo de texto
        self.message = discord.ui.TextInput(
            label="Mensagem",
            placeholder="Digite a mensagem personalizada",
            required=True,
            style=discord.TextInputStyle.paragraph,
            default=current_message
        )
        self.add_item(self.message)
    
    async def on_submit(self, interaction: discord.Interaction):
        # Carregar configuração
        try:
            with open('config/config.json', 'r', encoding='utf-8') as f:
                config = json.load(f)
        except:
            config = {}
        
        # Salvar mensagem na configuração
        config[self.config_key] = self.message.value
        
        # Salvar configuração
        with open('config/config.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4)
        
        # Confirmar salvamento
        await interaction.response.send_message(f"✅ Mensagem '{self.config_key}' salva com sucesso!", ephemeral=True)

class ConfigView(discord.ui.View):
    def __init__(self, ctx, current_config):
        super().__init__(timeout=300)  # 5 minutos
        self.ctx = ctx
        self.current_config = current_config
    
    @discord.ui.button(label="📢 Canais", style=discord.ButtonStyle.primary, custom_id="config_canais")
    async def config_canais(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Configurar canais do sistema"""
        # Criar embed
        embed = discord.Embed(
            title="⚙️ Configuração de Canais",
            description="Selecione os canais para o sistema de vendas",
            color=0xFD4556
        )
        
        # Criar view com botões para diferentes canais
        canais_view = discord.ui.View(timeout=180)  # 3 minutos
        
        # Botão para canal de admin
        admin_button = discord.ui.Button(
            label="📢 Canal de Administração", 
            style=discord.ButtonStyle.secondary,
            custom_id="admin_channel"
        )
        
        async def admin_callback(interaction):
            await interaction.response.send_modal(
                ChannelSelectModal("admin_channel", "Canal de Administração")
            )
        
        admin_button.callback = admin_callback
        canais_view.add_item(admin_button)
        
        # Botão para canal de logs públicos
        public_button = discord.ui.Button(
            label="📣 Canal de Logs Públicos", 
            style=discord.ButtonStyle.secondary,
            custom_id="public_log_channel"
        )
        
        async def public_callback(interaction):
            await interaction.response.send_modal(
                ChannelSelectModal("public_log_channel", "Canal de Logs Públicos")
            )
        
        public_button.callback = public_callback
        canais_view.add_item(public_button)
        
        # Botão para categoria
        category_button = discord.ui.Button(
            label="📁 Categoria de Vendas", 
            style=discord.ButtonStyle.secondary,
            custom_id="category_id"
        )
        
        async def category_callback(interaction):
            await interaction.response.send_modal(
                ChannelSelectModal("category_id", "Categoria de Vendas")
            )
        
        category_button.callback = category_callback
        canais_view.add_item(category_button)
        
        # Botão para voltar
        voltar_button = discord.ui.Button(
            label="⬅️ Voltar", 
            style=discord.ButtonStyle.danger,
            custom_id="voltar_config"
        )
        
        async def voltar_callback(interaction):
            # Recriar a view de configuração principal
            main_view = ConfigView(self.ctx, self.current_config)
            
            # Criar embed principal
            main_embed = discord.Embed(
                title="⚙️ Configuração do Sistema",
                description="Use os botões abaixo para configurar diferentes aspectos do sistema de vendas.",
                color=0xFD4556
            )
            
            await interaction.response.edit_message(embed=main_embed, view=main_view)
        
        voltar_button.callback = voltar_callback
        canais_view.add_item(voltar_button)
        
        # Responder à interação
        await interaction.response.edit_message(embed=embed, view=canais_view)
    
    @discord.ui.button(label="💰 Pagamento PIX", style=discord.ButtonStyle.primary, custom_id="config_pix")
    async def config_pix(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Configurar dados de PIX"""
        # Criar embed
        embed = discord.Embed(
            title="⚙️ Configuração de PIX",
            description="Configure os dados para pagamento via PIX",
            color=0xFD4556
        )
        
        # Criar view com botões para diferentes configurações de PIX
        pix_view = discord.ui.View(timeout=180)  # 3 minutos
        
        # Botão para chave PIX
        chave_button = discord.ui.Button(
            label="🔑 Chave PIX", 
            style=discord.ButtonStyle.secondary,
            custom_id="pix_chave"
        )
        
        async def chave_callback(interaction):
            await interaction.response.send_modal(
                ConfigModal("pix.chave", "Chave PIX", "Digite sua chave PIX (CPF, email, telefone ou chave aleatória)")
            )
        
        chave_button.callback = chave_callback
        pix_view.add_item(chave_button)
        
        # Botão para nome do recebedor
        nome_button = discord.ui.Button(
            label="👤 Nome do Recebedor", 
            style=discord.ButtonStyle.secondary,
            custom_id="pix_nome"
        )
        
        async def nome_callback(interaction):
            await interaction.response.send_modal(
                ConfigModal("pix.nome_recebedor", "Nome do Recebedor", "Digite o nome completo do recebedor")
            )
        
        nome_button.callback = nome_callback
        pix_view.add_item(nome_button)
        
        # Botão para cidade
        cidade_button = discord.ui.Button(
            label="🏙️ Cidade", 
            style=discord.ButtonStyle.secondary,
            custom_id="pix_cidade"
        )
        
        async def cidade_callback(interaction):
            await interaction.response.send_modal(
                ConfigModal("pix.cidade_recebedor", "Cidade", "Digite a cidade do recebedor")
            )
        
        cidade_button.callback = cidade_callback
        pix_view.add_item(cidade_button)
        
        # Botão para voltar
        voltar_button = discord.ui.Button(
            label="⬅️ Voltar", 
            style=discord.ButtonStyle.danger,
            custom_id="voltar_config"
        )
        
        async def voltar_callback(interaction):
            # Recriar a view de configuração principal
            main_view = ConfigView(self.ctx, self.current_config)
            
            # Criar embed principal
            main_embed = discord.Embed(
                title="⚙️ Configuração do Sistema",
                description="Use os botões abaixo para configurar diferentes aspectos do sistema de vendas.",
                color=0xFD4556
            )
            
            await interaction.response.edit_message(embed=main_embed, view=main_view)
        
        voltar_button.callback = voltar_callback
        pix_view.add_item(voltar_button)
        
        # Responder à interação
        await interaction.response.edit_message(embed=embed, view=pix_view)
    
    @discord.ui.button(label="👥 Administradores", style=discord.ButtonStyle.primary, custom_id="config_admins")
    async def config_admins(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Configurar administradores do sistema"""
        # Criar embed
        embed = discord.Embed(
            title="⚙️ Configuração de Administradores",
            description="Adicione ou remova administradores do sistema",
            color=0xFD4556
        )
        
        # Listar admins atuais
        admin_ids = self.current_config.get("admin_ids", [])
        if admin_ids:
            admin_list = []
            for admin_id in admin_ids:
                try:
                    user = interaction.client.get_user(admin_id)
                    if user:
                        admin_list.append(f"{user.mention} ({user.name})")
                    else:
                        admin_list.append(f"<@{admin_id}> (ID: {admin_id})")
                except:
                    admin_list.append(f"ID: {admin_id}")
            
            embed.add_field(
                name="👥 Administradores Atuais",
                value="\n".join(admin_list) or "Nenhum administrador configurado",
                inline=False
            )
        
        # Criar view com botões
        admin_view = discord.ui.View(timeout=180)  # 3 minutos
        
        # Botão para adicionar admin
        add_button = discord.ui.Button(
            label="➕ Adicionar Admin", 
            style=discord.ButtonStyle.success,
            custom_id="add_admin"
        )
        
        async def add_callback(interaction):
            await interaction.response.send_modal(
                ConfigModal("add_admin", "Adicionar Administrador", "Digite o ID do usuário")
            )
        
        add_button.callback = add_callback
        admin_view.add_item(add_button)
        
        # Botão para remover admin
        remove_button = discord.ui.Button(
            label="➖ Remover Admin", 
            style=discord.ButtonStyle.danger,
            custom_id="remove_admin"
        )
        
        async def remove_callback(interaction):
            # Criar select menu com os admins atuais
            if not admin_ids:
                await interaction.response.send_message("❌ Não há administradores configurados para remover.", ephemeral=True)
                return
            
            options = []
            for admin_id in admin_ids:
                try:
                    user = interaction.client.get_user(admin_id)
                    if user:
                        options.append(
                            discord.SelectOption(
                                label=f"{user.name}",
                                value=str(admin_id),
                                description=f"ID: {admin_id}"
                            )
                        )
                    else:
                        options.append(
                            discord.SelectOption(
                                label=f"Usuário ID: {admin_id}",
                                value=str(admin_id)
                            )
                        )
                except:
                    options.append(
                        discord.SelectOption(
                            label=f"ID: {admin_id}",
                            value=str(admin_id)
                        )
                    )
            
            select = discord.ui.Select(
                placeholder="Selecione o administrador para remover",
                options=options,
                custom_id="remove_admin_select"
            )
            
            async def select_callback(interaction):
                admin_id = int(select.values[0])
                
                # Remover da lista
                admin_ids.remove(admin_id)
                
                # Atualizar configuração
                self.current_config["admin_ids"] = admin_ids
                
                # Salvar configuração
                with open('config/config.json', 'w', encoding='utf-8') as f:
                    json.dump(self.current_config, f, indent=4)
                
                # Recriar a view de configuração de admins
                await self.config_admins(interaction, button)
                
                # Confirmar remoção
                user = interaction.client.get_user(admin_id)
                if user:
                    await interaction.followup.send(f"✅ Administrador {user.mention} removido com sucesso!", ephemeral=True)
                else:
                    await interaction.followup.send(f"✅ Administrador ID: {admin_id} removido com sucesso!", ephemeral=True)
            
            select.callback = select_callback
            
            # Criar view temporária
            temp_view = discord.ui.View()
            temp_view.add_item(select)
            
            await interaction.response.send_message("Selecione o administrador para remover:", view=temp_view, ephemeral=True)
        
        remove_button.callback = remove_callback
        admin_view.add_item(remove_button)
        
        # Botão para voltar
        voltar_button = discord.ui.Button(
            label="⬅️ Voltar", 
            style=discord.ButtonStyle.secondary,
            custom_id="voltar_config"
        )
        
        async def voltar_callback(interaction):
            # Recriar a view de configuração principal
            main_view = ConfigView(self.ctx, self.current_config)
            
            # Criar embed principal
            main_embed = discord.Embed(
                title="⚙️ Configuração do Sistema",
                description="Use os botões abaixo para configurar diferentes aspectos do sistema de vendas.",
                color=0xFD4556
            )
            
            await interaction.response.edit_message(embed=main_embed, view=main_view)
        
        voltar_button.callback = voltar_callback
        admin_view.add_item(voltar_button)
        
        # Responder à interação
        await interaction.response.edit_message(embed=embed, view=admin_view)
    
    @discord.ui.button(label="📋 Mensagens", style=discord.ButtonStyle.primary, custom_id="config_mensagens")
    async def config_mensagens(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Configurar mensagens do sistema"""
        # Criar embed
        embed = discord.Embed(
            title="⚙️ Configuração de Mensagens",
            description="Personalize as mensagens enviadas pelo sistema",
            color=0xFD4556
        )
        
        # Criar view com botões
        mensagens_view = discord.ui.View(timeout=180)  # 3 minutos
        
        # Botão para mensagem de aprovação
        aprovacao_button = discord.ui.Button(
            label="✅ Mensagem de Aprovação", 
            style=discord.ButtonStyle.secondary,
            custom_id="msg_aprovacao"
        )
        
        async def aprovacao_callback(interaction):
            await interaction.response.send_modal(
                MessageModal("mensagem_aprovacao", "Mensagem de Aprovação")
            )
        
        aprovacao_button.callback = aprovacao_callback
        mensagens_view.add_item(aprovacao_button)
        
        # Botão para mensagem de cancelamento
        cancelamento_button = discord.ui.Button(
            label="❌ Mensagem de Cancelamento", 
            style=discord.ButtonStyle.secondary,
            custom_id="msg_cancelamento"
        )
        
        async def cancelamento_callback(interaction):
            await interaction.response.send_modal(
                MessageModal("mensagem_cancelamento", "Mensagem de Cancelamento")
            )
        
        cancelamento_button.callback = cancelamento_callback
        mensagens_view.add_item(cancelamento_button)
        
        # Botão para voltar
        voltar_button = discord.ui.Button(
            label="⬅️ Voltar", 
            style=discord.ButtonStyle.danger,
            custom_id="voltar_config"
        )
        
        async def voltar_callback(interaction):
            # Recriar a view de configuração principal
            main_view = ConfigView(self.ctx, self.current_config)
            
            # Criar embed principal
            main_embed = discord.Embed(
                title="⚙️ Configuração do Sistema",
                description="Use os botões abaixo para configurar diferentes aspectos do sistema de vendas.",
                color=0xFD4556
            )
            
            await interaction.response.edit_message(embed=main_embed, view=main_view)
        
        voltar_button.callback = voltar_callback
        mensagens_view.add_item(voltar_button)
        
        # Responder à interação
        await interaction.response.edit_message(embed=embed, view=mensagens_view)
